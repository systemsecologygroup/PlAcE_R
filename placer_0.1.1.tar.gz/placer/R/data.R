#' Caspian terns plastic debris in Senegal.
#'
#' A dataset containing absence and presence observations
#' of plastic debris for the Caspian terns in the coast
#' of Senegal.
#'
#'
#' @format A data frame with 529 rows and 8 variables:
#' \describe{
#'   \item{species}{species name, more info}
#'   \item{location}{location, more info}
#'   \item{country}{country, more info}
#'   \item{latitude}{latitude, more info}
#'   \item{longitude}{longitude, more info}
#'   \item{year}{year, more info}
#'   \item{nest_code}{nest code, more info}
#'   \item{debris_presence}{debris presence absence, more info }
#' }
#' @source Tavares et al. ...
"ctern"
