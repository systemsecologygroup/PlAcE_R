# Main functions to estimate confidence intervals for prevalence of
# plastic debris in seabird nests as a function of different
# sample sizes.
#
# Developed by: Davi Castro Tavares
# Date: May 2018
# Modified by: Esteban Acevedo-Trejos
# Date: July 2019
#-------------------------------------------------------------------


plastic.freq <- function(plastic_abs_pres, sample_size){
  # Funtion to estimate the prevalence of plastic from a randomly
  # selected sample of presence/absence observations of plastic debris.
  # @Params
  # plastic_pre_abs: Binary variable with 0 or no (for absence) and 1 or yes (for presence)
  # sampel_size: Sample size to extract

  #defining the expected prevalence for a given sample size,
  #by dividing the number of rows with yes by the total number of rows
  #in the data. Size is going to be the number of samples to be simulated,
  #and varies from 1 to 300. It will be defined in the upcoming lines of code (marked in blue).

  if(length(unique(plastic_abs_pres)) != 2){
    # check whether a given variable is binary
    stop('input variable plastic_abs_pre is not a binary varible')
  } else if(all(sort(unique(plastic_abs_pres)) != c(0,1)) |
            all(sort(unique(plastic_abs_pres)) != c('no','yes'))){
    stop('values of bynary variable must be 0 or no (for absence) and 1 or yes (for presence)' )
  } else {
    rand_sample <- dplyr::sample_n(data.frame(plastic_abs_pres), sample_size, replace = TRUE)
    plastic_prev <- nrow(subset(rand_sample, rand_sample == 1 | rand_sample == 'yes')) / nrow(rand_sample)
    return(plastic_prev)
  }
}


plastic.ci <- function(plastic_pre_abs, max_ss=300, bs_rep=1000){
  # Bootstrap simulations to estimate prevalence of plastic debris in seabirds' nests.
  # The 95% confidence intervals are calculated in a sequence of sample sizes, ranging for
  # example from 1 to 300 nests sampled.
  output = list()

  for(size in seq(1, 300, 1)){
    #defining a sequence of samples that should be created for calculating prevalence.
    result = replicate(1000, freq(northern_gannets))#replicating the code above 1000 times.
    output = c(output, list(result))

    output = data.frame(output)
  }

}
